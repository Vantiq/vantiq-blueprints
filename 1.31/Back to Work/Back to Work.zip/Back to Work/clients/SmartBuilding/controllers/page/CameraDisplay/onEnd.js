	var ds = client.getDataStreamByName("dc_sensors_CameraDisplay");
    ds.isPaused = true;