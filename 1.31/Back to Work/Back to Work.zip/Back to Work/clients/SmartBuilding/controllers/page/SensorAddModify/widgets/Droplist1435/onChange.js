	// repopulate sensor configs with choice
    page.data.refreshSensorConfigs();