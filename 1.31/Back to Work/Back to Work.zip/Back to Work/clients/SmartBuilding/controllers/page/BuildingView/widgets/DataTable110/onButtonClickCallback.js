    if(extra.columnName === "ButtonView"){
     	console.log(extra);
        client.goToPage("FloorPlanView", extra.dataObject);
    }