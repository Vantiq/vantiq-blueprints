The Back-To-Work Accelerator includes the main client that provides the foundation for modeling workplaces and serves as the dashboard for monitoring all issues that may be detected and reported.  Additionally, the fundamental types that define the workplace hierarchy of buildings, floors, spaces, assets and sensor are all included, as well as a collection of useful Procedures.
 
Optional plugins that implement solutions for specific use cases can also be selected and loaded.
