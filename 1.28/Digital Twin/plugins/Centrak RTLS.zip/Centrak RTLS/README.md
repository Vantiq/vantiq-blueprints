Integrate with the Centrak Real Time Location System to add precise location events to the SmartBuilding Client.
