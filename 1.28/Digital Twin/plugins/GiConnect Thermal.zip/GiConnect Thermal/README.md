Generate sample location events that will simulate motion in the SmartBuilding Client.

This plugin is modeled off of the expected data format of Centrak Real Time Location system.
