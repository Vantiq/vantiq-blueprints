	var page = this;

    page.data.refreshSimulations = function(){
        //sim.getSimulations()
        client.data.execute("sim.getSimulations", {}, function(response){
            client.sendClientEvent("ce_s_simulations", response);
        });
    };
    
    page.data.refreshSimulationGroups = function(){
        //sim.getSimulationGroups()
        client.data.execute("sim.getSimulationGroups", {}, function(response){
            client.sendClientEvent("ce_s_simulationgroups", response);
        });
    };
    
    page.data.refreshSimulations();
    page.data.refreshSimulationGroups();
    

    
    
    

