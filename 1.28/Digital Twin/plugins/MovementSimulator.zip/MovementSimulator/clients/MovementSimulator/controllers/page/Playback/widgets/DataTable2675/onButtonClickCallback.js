	
    if (extra.columnName === "ButtonPlay"){
        //sim.playbackGroupSimulation(simgroup String)
        var args ={};
        args.simgroup = extra.dataObject.simgroup;
        client.data.execute("sim.playbackGroupSimulation", args, function(response){
        });
    }
