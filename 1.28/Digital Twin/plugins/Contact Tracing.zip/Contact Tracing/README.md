Detect potential contacts between people in real time to enable Contact Tracing in the Smart Building. Snapshots of contacts are saved for a limited time to efficiently compute the list of contacts a person made in the building over the last 24-48 hours. 

This plugin requires the use of additional plugins to produce the location data necessray to determine contacts. Take a look at the Centrak RTLS plugin for one potential location system.
