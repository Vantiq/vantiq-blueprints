	client.data.execute("unittest.handevent", {id: client.getUsername()}, function(response){
    	client.terminate();
	});