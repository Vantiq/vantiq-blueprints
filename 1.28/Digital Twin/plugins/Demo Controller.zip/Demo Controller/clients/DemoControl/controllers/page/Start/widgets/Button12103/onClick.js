	client.data.execute("unittest.handSanitizerNormalEvent", {}, function(response){
    	client.terminate();
	});