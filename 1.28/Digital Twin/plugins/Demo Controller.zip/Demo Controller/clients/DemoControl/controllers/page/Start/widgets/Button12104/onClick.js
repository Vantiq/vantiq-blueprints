	client.data.execute("unittest.handSanitizerHighEvent", {}, function(response){
    	client.terminate();
	});