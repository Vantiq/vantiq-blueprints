    client.data.execute("demo.removeAllCollabAndSit", {}, function(response){
        client.terminate();
    });

   