	client.data.execute("unittest.handSanitizerLowEvent", {}, function(response){
    	client.terminate();
	});