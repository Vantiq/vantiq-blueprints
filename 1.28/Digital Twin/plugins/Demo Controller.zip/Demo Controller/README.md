This plugin provides integration with the GiConnect thermal camera, which can precicely detect temperatures to enable automated  fever detection. 
