Integrate with volume sensors in Refuse Containers to detect when bins need to be emptied. 

This plugin adds a new issue type to the SmartBuilding Client and a corresponding Collaboration Type.
