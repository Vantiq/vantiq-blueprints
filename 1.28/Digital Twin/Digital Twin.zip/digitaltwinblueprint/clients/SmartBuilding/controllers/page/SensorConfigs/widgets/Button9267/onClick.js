   /*
   var params = {};

   client.popupPage("SensorConfigAddModify","Add a sensor config",null,function(returnParameters){    
       console.log("The Return Parameters: " + returnParameters);
   });
   */
    
    client.goToPage("SensorConfigAddModify");