	console.log(extra);
    if(extra.columnName === "ButtonEdit"){
        client.goToPage("PersonAddModify", extra.dataObject);
    }