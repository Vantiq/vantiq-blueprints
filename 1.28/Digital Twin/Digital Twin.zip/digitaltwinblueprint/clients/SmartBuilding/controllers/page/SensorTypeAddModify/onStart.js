    var page = this;

    page.data.sensortype.initializeToDefaultValues();
    
     
    if (parameters){
        page.data.sensortype.copyMatchingData(parameters);
    } 
    
    


    
    
    
