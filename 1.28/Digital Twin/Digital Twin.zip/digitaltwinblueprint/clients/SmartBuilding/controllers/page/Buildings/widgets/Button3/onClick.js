   client.popupPage("BuildingAddModify","Add a building", null,function(returnParameters){    
       page.data.refreshBuildings();
   });