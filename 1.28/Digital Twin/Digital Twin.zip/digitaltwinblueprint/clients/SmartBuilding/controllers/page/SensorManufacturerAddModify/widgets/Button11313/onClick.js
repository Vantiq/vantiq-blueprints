client.data.insert("sensormanufacturers", page.data.sensormanufacturers.values, function(response){
    client.closePopup();
});
