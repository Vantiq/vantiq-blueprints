client.getDataStreamByName("dc_system_collaborations").isPaused = true;
    
    // _SrollingFrame_ for Start page no Y scrolling
    //$("#_ScrollingFrame_").css({"overflow": "hidden auto"});