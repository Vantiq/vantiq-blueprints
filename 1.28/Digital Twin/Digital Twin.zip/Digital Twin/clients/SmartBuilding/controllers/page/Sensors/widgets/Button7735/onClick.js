
   /*
   client.popupPage("SensorAddModify","Add a sensor",null,function(returnParameters)
   {    
       console.log("The Return Parameters: " + returnParameters);
       page.data.refreshSensors();
   });
   */
    
    client.goToPage("SensorAddModify");