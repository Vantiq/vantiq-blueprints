    var page = this;

    page.data.sensormanufacturers.initializeToDefaultValues();

   
