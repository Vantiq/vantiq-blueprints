The Digital Twin SMAART Accelerator provides the foundation for building a complete application that visualizes and monitors your building. 

The core project includes the main client that visualizes the building and serves as the dashboard for monitoring all issues. 
Additionally, the fundamental types that define buildings, spaces, assets and sensors are all included, as well as a collection
of useful Procedures.

Additional functionality, such as Contact Tracing, High Temperature Detection, and Centrak RTLS integration are available
through plugins contributed by our Partners. 

