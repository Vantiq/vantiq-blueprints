Detect situations where people are not maintaining appropriate physical distance and when spaces are overcrowded by tracking motion with cameras. When violations are detected, notify security through a custom mobile client.

The apps are designed to pull data from the Object Recognition Extension source. 
