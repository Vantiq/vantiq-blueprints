
   client.goToPage("PersonAddModify");
 