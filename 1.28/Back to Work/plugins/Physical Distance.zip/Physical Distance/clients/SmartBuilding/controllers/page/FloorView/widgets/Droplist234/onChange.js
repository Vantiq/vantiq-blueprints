
    page.data.refreshSpacesAndAssets();
    
    