	if (page.data.person.isCollaborator){
        client.getWidget("InputString7546").isVisible = true;
        client.getWidget("VerticalLayout10991").isVisible = true;
        
        
    } else {
        client.getWidget("InputString7546").isVisible = false;
        client.getWidget("VerticalLayout10991").isVisible = false;
    }