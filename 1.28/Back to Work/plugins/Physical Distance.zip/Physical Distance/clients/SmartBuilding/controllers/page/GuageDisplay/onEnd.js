	// pause the sensor datastream
    client.getDataStreamByName("tq_sensors").isPaused = true;