

    page.data.asset.floorid = page.data.floor;
    page.data.populateSpaceDropDown();