	console.log(extra);
    if (extra.columnName === "ButtonEdit"){
        client.goToPage("SensorConfigAddModify", extra.dataObject);
    }