	// pause the datastream 
    var ds = client.getDataStreamByName("dc_assets");
    ds.isPaused = true;