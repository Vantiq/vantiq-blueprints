	client.data.upsert("organization", client.data.organization, function(response){
    	client.goToPage("Start");
	});