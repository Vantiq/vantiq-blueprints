Improve safety compliance by ensuring hand santizer stations are full and regularly used by employees. 
This plugin is capable of detecting when hand santizer stations run low on sanitizing solution as well 
as when employees go too long without cleaning their hands.
