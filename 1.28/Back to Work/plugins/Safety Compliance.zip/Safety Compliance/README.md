Using volume sensors, various safety or hygiene equipment can be monitored to see if something needs to be filled or emptied.
