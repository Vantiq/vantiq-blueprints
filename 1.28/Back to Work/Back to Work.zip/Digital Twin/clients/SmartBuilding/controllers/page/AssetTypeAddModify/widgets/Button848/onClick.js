	client.data.upsert("assettypes", page.data.assettype, function(response){
    	client.closePopup();
	});