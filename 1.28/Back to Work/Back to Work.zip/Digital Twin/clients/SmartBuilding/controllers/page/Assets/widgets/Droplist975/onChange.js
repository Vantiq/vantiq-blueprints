	console.log(page.data.floorid);
    page.data.refreshAssets();
    