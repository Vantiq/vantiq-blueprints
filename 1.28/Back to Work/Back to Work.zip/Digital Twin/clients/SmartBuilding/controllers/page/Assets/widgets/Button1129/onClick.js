    

    client.popupPage("AssetAddModify","Add an asset",null ,function(returnParameters){    
        page.data.refreshAssets();
    });
