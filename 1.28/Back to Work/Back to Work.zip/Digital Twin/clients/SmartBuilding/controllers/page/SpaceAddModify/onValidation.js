
    /*if (page.data.space.floorplanlocation === null){
                vco.error = "You have not selected a location on the floorplan for this space";

    }	
    */