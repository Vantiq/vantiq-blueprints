    client.data.upsert("roles", page.data.role, function(response){
		client.closePopup(); 
    });