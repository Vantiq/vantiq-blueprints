	var page = this;
    page.data.assettype.initializeToDefaultValues();
