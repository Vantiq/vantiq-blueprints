	
    page.data.foregroundColor = page.data.navbarBackgrounColor;
    $('#InputString8536 input').minicolors('value',page.data.navbarBackgrounColor);
    
    page.data.buttonBackgroundColor = page.data.navbarBackgrounColor;
    $('#InputString8537 input').minicolors('value',page.data.navbarBackgrounColor);
    
    
    $('#HorizontalLayout9973').css('background-color', page.data.navbarBackgrounColor);
    
    
    
    