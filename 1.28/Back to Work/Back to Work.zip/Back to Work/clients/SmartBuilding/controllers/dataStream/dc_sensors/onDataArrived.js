	


    //
     
    
    
    /*
    console.log("data");
    console.log(data);
    console.log("page");
    console.log(page.name);
    
    
    // guage page
    if (page.name === "GaugeDisplay"){
        if (data.id === page.data.sensor.id){
            console.log("page.data.sensor.id");
            console.log(page.data.sensor.id);
            client.sendClientEvent("ce_s_volumesensor_GaugeDisplay", data);
        }
    }
    
    */
    
    