	
    var page = client.getCurrentPage();
    if (page.name === "Start")
    	client.data.refreshDashboard();